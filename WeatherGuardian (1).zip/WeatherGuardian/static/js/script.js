// Global variables
let currentLocation = "New York";

// DOM Elements
const locationInput = document.getElementById('location-input');
const searchButton = document.getElementById('search-button');
const loadingIndicator = document.getElementById('loading');
const errorAlert = document.getElementById('error-alert');
const errorMessage = document.getElementById('error-message');
const currentWeatherContainer = document.getElementById('current-weather');
const forecastDataContainer = document.getElementById('forecast-data');
const weatherSpecificTips = document.getElementById('weather-specific-tips');
const chatMessages = document.getElementById('chat-messages');
const chatInput = document.getElementById('chat-input');
const sendButton = document.getElementById('send-button');

// Event Listeners
document.addEventListener('DOMContentLoaded', () => {
    // Load default data on page load
    getWeatherData(currentLocation);
    
    // Search button click event
    searchButton.addEventListener('click', () => {
        const location = locationInput.value.trim();
        if (location) {
            currentLocation = location;
            getWeatherData(location);
        }
    });
    
    // Location input enter key event
    locationInput.addEventListener('keypress', (e) => {
        if (e.key === 'Enter') {
            const location = locationInput.value.trim();
            if (location) {
                currentLocation = location;
                getWeatherData(location);
            }
        }
    });
    
    // Send button click event (chatbot)
    sendButton.addEventListener('click', sendChatMessage);
    
    // Chat input enter key event
    chatInput.addEventListener('keypress', (e) => {
        if (e.key === 'Enter') {
            sendChatMessage();
        }
    });
});

// Function to fetch all weather data
async function getWeatherData(location) {
    // Show loading indicator and hide error
    showLoading(true);
    hideError();
    
    try {
        // Fetch current weather and forecast in parallel
        const [weatherResponse, forecastResponse] = await Promise.all([
            fetch(`/api/weather?location=${encodeURIComponent(location)}`),
            fetch(`/api/forecast?location=${encodeURIComponent(location)}`)
        ]);
        
        // Check for HTTP errors
        if (!weatherResponse.ok) throw new Error('Failed to fetch current weather data');
        if (!forecastResponse.ok) throw new Error('Failed to fetch forecast data');
        
        // Parse JSON responses
        const weatherData = await weatherResponse.json();
        const forecastData = await forecastResponse.json();
        
        // Display the data
        displayCurrentWeather(weatherData);
        displayForecast(forecastData);
        displayWeatherTips(weatherData);
        
    } catch (error) {
        console.error('Error fetching weather data:', error);
        showError(error.message || 'Failed to fetch weather data. Please try again.');
    } finally {
        showLoading(false);
    }
}

// Display current weather data
function displayCurrentWeather(data) {
    if (data.error) {
        currentWeatherContainer.innerHTML = `<p class="text-danger">${data.error}</p>`;
        return;
    }
    
    const weatherIconUrl = getWeatherIconSvg(data.icon);
    const date = new Date(data.timestamp);
    const formattedDate = date.toLocaleDateString('en-US', { 
        weekday: 'long', 
        year: 'numeric', 
        month: 'long', 
        day: 'numeric' 
    });
    const formattedTime = date.toLocaleTimeString('en-US', { 
        hour: '2-digit', 
        minute: '2-digit' 
    });
    
    currentWeatherContainer.innerHTML = `
        <div class="text-center mb-4">
            <h4 class="mb-1">${data.location}, ${data.country}</h4>
            <p class="text-muted">${formattedDate} at ${formattedTime}</p>
        </div>
        
        <div class="row align-items-center">
            <div class="col-5 text-center">
                <img src="${weatherIconUrl}" alt="${data.description}" class="img-fluid" style="max-width: 100px;">
                <p class="mt-2 text-capitalize">${data.description}</p>
            </div>
            <div class="col-7">
                <h2 class="display-4 mb-0">${Math.round(data.temperature)}°C</h2>
                <p class="text-muted">Feels like ${Math.round(data.feels_like)}°C</p>
                
                <div class="weather-details mt-3">
                    <div class="row">
                        <div class="col-6">
                            <p><i class="fas fa-wind me-2"></i> Wind: ${data.wind_speed} m/s</p>
                            <p><i class="fas fa-tint me-2"></i> Humidity: ${data.humidity}%</p>
                        </div>
                        <div class="col-6">
                            <p><i class="fas fa-compress-alt me-2"></i> Pressure: ${data.pressure} hPa</p>
                            <p><i class="fas fa-sun me-2"></i> Sunrise: ${data.sunrise}</p>
                            <p><i class="fas fa-moon me-2"></i> Sunset: ${data.sunset}</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    `;
}

// Display weather alerts
function displayWeatherAlerts(data) {
    if (data.error) {
        weatherAlertsContainer.innerHTML = `<p class="text-danger">${data.error}</p>`;
        return;
    }
    
    // Handle subscription required message
    if (data.subscription_required) {
        weatherAlertsContainer.innerHTML = `
            <div class="alert alert-warning">
                <i class="fas fa-info-circle me-2"></i>
                <strong>Weather Alerts Information</strong>
            </div>
            <p class="text-center mt-3">
                <i class="fas fa-lock text-warning" style="font-size: 3rem;"></i>
            </p>
            <p class="text-center">
                Weather alerts require an OpenWeather paid subscription.
            </p>
            <p class="text-center text-muted">
                This application is using a free API key which doesn't provide access to weather alerts.
            </p>
            <div class="alert alert-info mt-3">
                <i class="fas fa-shield-alt me-2"></i>
                You can still access current weather and forecast information. 
                For severe weather, check your local weather service.
            </div>
        `;
        return;
    }
    
    // Display alerts if available
    if (data.alerts && data.alerts.length > 0) {
        let alertsHtml = `<div class="alert alert-danger mb-3">
                            <i class="fas fa-exclamation-triangle me-2"></i>
                            <strong>${data.alerts.length} active weather ${data.alerts.length === 1 ? 'alert' : 'alerts'} for ${data.location}</strong>
                          </div>`;
        
        alertsHtml += `<div class="list-group">`;
        data.alerts.forEach(alert => {
            const startDate = new Date(alert.start);
            const endDate = new Date(alert.end);
            
            alertsHtml += `
                <div class="list-group-item list-group-item-danger">
                    <div class="d-flex w-100 justify-content-between">
                        <h5 class="mb-1">${alert.event}</h5>
                    </div>
                    <p class="mb-1">${alert.description}</p>
                    <small>
                        <strong>From:</strong> ${startDate.toLocaleString()} <br>
                        <strong>Until:</strong> ${endDate.toLocaleString()} <br>
                        <strong>Source:</strong> ${alert.sender}
                    </small>
                </div>
            `;
        });
        alertsHtml += `</div>`;
        
        weatherAlertsContainer.innerHTML = alertsHtml;
    } else {
        weatherAlertsContainer.innerHTML = `
            <div class="alert alert-success">
                <i class="fas fa-check-circle me-2"></i>
                No active weather alerts for ${data.location}
            </div>
            <p class="text-center mt-4">
                <i class="fas fa-shield-alt text-success" style="font-size: 3rem;"></i>
            </p>
            <p class="text-center text-muted">
                Stay prepared! Even when there are no active alerts, it's good to check the forecast regularly.
            </p>
        `;
    }
}

// Display 5-day forecast
function displayForecast(data) {
    if (data.error) {
        forecastDataContainer.innerHTML = `<p class="text-danger">${data.error}</p>`;
        return;
    }
    
    if (data.forecast && data.forecast.length > 0) {
        let forecastHtml = '';
        
        data.forecast.forEach(day => {
            const weatherIconUrl = getWeatherIconSvg(day.icon);
            
            forecastHtml += `
                <div class="col">
                    <div class="card text-center h-100">
                        <div class="card-body">
                            <h5 class="card-title">${day.day}</h5>
                            <h6 class="card-subtitle mb-2 text-muted">${day.date}</h6>
                            <img src="${weatherIconUrl}" alt="${day.description}" class="img-fluid my-3" style="max-width: 64px;">
                            <p class="card-text text-capitalize">${day.description}</p>
                            <h4>${Math.round(day.temperature)}°C</h4>
                            <p class="text-muted">Feels like ${Math.round(day.feels_like)}°C</p>
                            <p><i class="fas fa-tint me-1"></i> ${day.humidity}%</p>
                        </div>
                    </div>
                </div>
            `;
        });
        
        forecastDataContainer.innerHTML = forecastHtml;
    } else {
        forecastDataContainer.innerHTML = `<p class="text-center text-muted">No forecast data available</p>`;
    }
}

// Display weather-specific safety tips
function displayWeatherTips(data) {
    if (!data || data.error) {
        weatherSpecificTips.innerHTML = '';
        return;
    }
    
    let tipsHtml = `<h4 class="mt-4">Weather-Specific Safety Tips</h4>`;
    
    // Determine tips based on weather conditions
    const description = data.description.toLowerCase();
    const temp = data.temperature;
    
    if (description.includes('rain') || description.includes('drizzle') || description.includes('shower')) {
        tipsHtml += getTipsForCondition('rain');
    } 
    else if (description.includes('snow') || description.includes('blizzard')) {
        tipsHtml += getTipsForCondition('snow');
    }
    else if (description.includes('storm') || description.includes('thunder')) {
        tipsHtml += getTipsForCondition('storm');
    }
    else if (description.includes('fog') || description.includes('mist')) {
        tipsHtml += `
            <ul class="list-group list-group-flush mb-3">
                <li class="list-group-item"><i class="fas fa-check-circle text-success me-2"></i>Use low-beam headlights when driving in fog</li>
                <li class="list-group-item"><i class="fas fa-check-circle text-success me-2"></i>Reduce speed and increase following distance</li>
                <li class="list-group-item"><i class="fas fa-check-circle text-success me-2"></i>Consider delaying travel until fog clears</li>
            </ul>
        `;
    }
    else if (temp > 30) { // Hot weather
        tipsHtml += getTipsForCondition('heat');
    }
    else if (temp < 0) { // Cold weather
        tipsHtml += getTipsForCondition('cold');
    }
    else {
        tipsHtml += `
            <ul class="list-group list-group-flush mb-3">
                <li class="list-group-item"><i class="fas fa-check-circle text-success me-2"></i>Stay informed about changing weather conditions</li>
                <li class="list-group-item"><i class="fas fa-check-circle text-success me-2"></i>Keep an eye on the forecast for your area</li>
                <li class="list-group-item"><i class="fas fa-check-circle text-success me-2"></i>Prepare for seasonal weather changes</li>
            </ul>
        `;
    }
    
    weatherSpecificTips.innerHTML = tipsHtml;
}

// Get tips for specific weather condition
function getTipsForCondition(condition) {
    const tipsByCondition = {
        'rain': `
            <ul class="list-group list-group-flush mb-3">
                <li class="list-group-item"><i class="fas fa-check-circle text-success me-2"></i>Carry an umbrella or raincoat</li>
                <li class="list-group-item"><i class="fas fa-check-circle text-success me-2"></i>Avoid driving through flooded areas</li>
                <li class="list-group-item"><i class="fas fa-check-circle text-success me-2"></i>Be aware of slippery surfaces</li>
            </ul>
        `,
        'snow': `
            <ul class="list-group list-group-flush mb-3">
                <li class="list-group-item"><i class="fas fa-check-circle text-success me-2"></i>Dress in warm layers and wear proper footwear</li>
                <li class="list-group-item"><i class="fas fa-check-circle text-success me-2"></i>Drive slowly and maintain distance from other vehicles</li>
                <li class="list-group-item"><i class="fas fa-check-circle text-success me-2"></i>Keep emergency supplies in your vehicle</li>
                <li class="list-group-item"><i class="fas fa-check-circle text-success me-2"></i>Clear snow from walkways and driveways to prevent falls</li>
            </ul>
        `,
        'storm': `
            <ul class="list-group list-group-flush mb-3">
                <li class="list-group-item"><i class="fas fa-check-circle text-success me-2"></i>Stay indoors and away from windows during storms</li>
                <li class="list-group-item"><i class="fas fa-check-circle text-success me-2"></i>Unplug electronic devices to prevent damage from lightning</li>
                <li class="list-group-item"><i class="fas fa-check-circle text-success me-2"></i>Have flashlights and batteries ready for power outages</li>
                <li class="list-group-item"><i class="fas fa-check-circle text-success me-2"></i>If outdoors, seek shelter immediately - avoid trees and open areas</li>
            </ul>
        `,
        'heat': `
            <ul class="list-group list-group-flush mb-3">
                <li class="list-group-item"><i class="fas fa-check-circle text-success me-2"></i>Stay hydrated by drinking plenty of water</li>
                <li class="list-group-item"><i class="fas fa-check-circle text-success me-2"></i>Avoid strenuous activities during peak heat hours</li>
                <li class="list-group-item"><i class="fas fa-check-circle text-success me-2"></i>Wear lightweight, light-colored clothing</li>
                <li class="list-group-item"><i class="fas fa-check-circle text-success me-2"></i>Check on elderly neighbors and never leave children or pets in hot cars</li>
            </ul>
        `,
        'cold': `
            <ul class="list-group list-group-flush mb-3">
                <li class="list-group-item"><i class="fas fa-check-circle text-success me-2"></i>Dress in warm layers and protect extremities</li>
                <li class="list-group-item"><i class="fas fa-check-circle text-success me-2"></i>Limit time outdoors in extreme cold</li>
                <li class="list-group-item"><i class="fas fa-check-circle text-success me-2"></i>Watch for signs of hypothermia and frostbite</li>
                <li class="list-group-item"><i class="fas fa-check-circle text-success me-2"></i>Keep emergency supplies in your vehicle</li>
            </ul>
        `
    };
    
    return tipsByCondition[condition] || '';
}

// Get weather icon SVG
function getWeatherIconSvg(iconCode) {
    // Map OpenWeatherMap icon codes to our local SVG icons
    const iconMapping = {
        '01d': '/static/icons/weather-icons.svg#clear-day',
        '01n': '/static/icons/weather-icons.svg#clear-night',
        '02d': '/static/icons/weather-icons.svg#partly-cloudy-day',
        '02n': '/static/icons/weather-icons.svg#partly-cloudy-night',
        '03d': '/static/icons/weather-icons.svg#cloudy',
        '03n': '/static/icons/weather-icons.svg#cloudy',
        '04d': '/static/icons/weather-icons.svg#cloudy',
        '04n': '/static/icons/weather-icons.svg#cloudy',
        '09d': '/static/icons/weather-icons.svg#rain',
        '09n': '/static/icons/weather-icons.svg#rain',
        '10d': '/static/icons/weather-icons.svg#rain',
        '10n': '/static/icons/weather-icons.svg#rain',
        '11d': '/static/icons/weather-icons.svg#thunderstorm',
        '11n': '/static/icons/weather-icons.svg#thunderstorm',
        '13d': '/static/icons/weather-icons.svg#snow',
        '13n': '/static/icons/weather-icons.svg#snow',
        '50d': '/static/icons/weather-icons.svg#fog',
        '50n': '/static/icons/weather-icons.svg#fog'
    };
    
    // Fallback to a default icon if the code is not found
    const iconUrl = iconMapping[iconCode] || '/static/icons/weather-icons.svg#cloudy';
    
    // For SVG icons, we use the sprite approach where each icon is referenced by its ID in the SVG file
    return iconUrl;
}

// Chatbot functionality
function sendChatMessage() {
    const message = chatInput.value.trim();
    if (!message) return;
    
    // Add user message to chat
    addMessageToChat(message, 'user');
    chatInput.value = '';
    
    // Show "typing" indication
    const typingDiv = document.createElement('div');
    typingDiv.className = 'message bot-message typing-indicator';
    typingDiv.innerHTML = '<div class="message-content"><i class="fas fa-robot me-2"></i>Typing...</div>';
    chatMessages.appendChild(typingDiv);
    chatMessages.scrollTop = chatMessages.scrollHeight;
    
    // Send message to chatbot API
    fetch('/api/chatbot', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({ message: message }),
    })
    .then(response => {
        // Remove typing indicator
        const typingIndicator = document.querySelector('.typing-indicator');
        if (typingIndicator) {
            chatMessages.removeChild(typingIndicator);
        }
        
        if (!response.ok) {
            console.error('Server response not OK:', response.status);
            throw new Error('Failed to get chatbot response: ' + response.status);
        }
        return response.json();
    })
    .then(data => {
        console.log('Chatbot response data:', data);
        // Add chatbot response to chat
        if (data && data.response) {
            addMessageToChat(data.response, 'bot');
        } else if (data && data.error) {
            addMessageToChat('Sorry, I encountered an error: ' + data.error, 'bot');
        } else {
            addMessageToChat('Received an empty or invalid response from the server.', 'bot');
        }
    })
    .catch(error => {
        console.error('Chatbot error:', error);
        addMessageToChat('Sorry, I\'m having trouble processing your request. Please try again.', 'bot');
    });
}

// Add message to chat display
function addMessageToChat(message, sender) {
    const messageDiv = document.createElement('div');
    messageDiv.className = `message ${sender}-message`;
    
    const messageContent = document.createElement('div');
    messageContent.className = 'message-content';
    
    if (sender === 'bot') {
        messageContent.innerHTML = `<i class="fas fa-robot me-2"></i>${message}`;
    } else {
        messageContent.innerHTML = `<i class="fas fa-user me-2"></i>${message}`;
    }
    
    messageDiv.appendChild(messageContent);
    chatMessages.appendChild(messageDiv);
    
    // Scroll to bottom of chat
    chatMessages.scrollTop = chatMessages.scrollHeight;
}

// Utility functions
function showLoading(isLoading) {
    if (isLoading) {
        loadingIndicator.classList.remove('d-none');
    } else {
        loadingIndicator.classList.add('d-none');
    }
}

function showError(message) {
    errorMessage.textContent = message;
    errorAlert.classList.remove('d-none');
}

function hideError() {
    errorAlert.classList.add('d-none');
}
